﻿Partial Class ist2gqDataSet
End Class

Namespace ist2gqDataSetTableAdapters

    Partial Public Class tblCustomerTableAdapter
    End Class
End Namespace
