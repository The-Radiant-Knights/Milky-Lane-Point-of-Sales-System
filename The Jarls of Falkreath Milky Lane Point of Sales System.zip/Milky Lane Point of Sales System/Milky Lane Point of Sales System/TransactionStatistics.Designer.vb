﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TransactionStatistics
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(TransactionStatistics))
        Me.LabelStatistics = New System.Windows.Forms.Label()
        Me.LabelNumTransactions = New System.Windows.Forms.Label()
        Me.LabelAvgTransactionAmount = New System.Windows.Forms.Label()
        Me.LabelAvgAmountPaid = New System.Windows.Forms.Label()
        Me.LabelAvgChangeGiven = New System.Windows.Forms.Label()
        Me.LabelAvgDateOfTransaction = New System.Windows.Forms.Label()
        Me.ButtonBack = New System.Windows.Forms.Button()
        Me.TextBoxNumTransactions = New System.Windows.Forms.TextBox()
        Me.TextBoxAvgTransactionAmount = New System.Windows.Forms.TextBox()
        Me.TextBoxAvgAmountPaid = New System.Windows.Forms.TextBox()
        Me.TextBoxAvgChangeGiven = New System.Windows.Forms.TextBox()
        Me.TextBoxAvgDateOfTransaction = New System.Windows.Forms.TextBox()
        Me.LabelMostProductiveEmployee = New System.Windows.Forms.Label()
        Me.TextBoxMostProductiveEmployee = New System.Windows.Forms.TextBox()
        Me.Ist2gqDataSet = New Milky_Lane_Point_of_Sales_System.ist2gqDataSet()
        Me.TableAdapterManager = New Milky_Lane_Point_of_Sales_System.ist2gqDataSetTableAdapters.TableAdapterManager()
        Me.TblInvoiceTableAdapter = New Milky_Lane_Point_of_Sales_System.ist2gqDataSetTableAdapters.tblInvoiceTableAdapter()
        Me.TblStaffTableAdapter = New Milky_Lane_Point_of_Sales_System.ist2gqDataSetTableAdapters.tblStaffTableAdapter()
        CType(Me.Ist2gqDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LabelStatistics
        '
        Me.LabelStatistics.AutoSize = True
        Me.LabelStatistics.BackColor = System.Drawing.Color.Transparent
        Me.LabelStatistics.Font = New System.Drawing.Font("Arial Rounded MT Bold", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelStatistics.Location = New System.Drawing.Point(12, 28)
        Me.LabelStatistics.Name = "LabelStatistics"
        Me.LabelStatistics.Size = New System.Drawing.Size(110, 24)
        Me.LabelStatistics.TabIndex = 16
        Me.LabelStatistics.Text = "Statistics:"
        '
        'LabelNumTransactions
        '
        Me.LabelNumTransactions.AutoSize = True
        Me.LabelNumTransactions.BackColor = System.Drawing.Color.Transparent
        Me.LabelNumTransactions.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelNumTransactions.Location = New System.Drawing.Point(13, 90)
        Me.LabelNumTransactions.Name = "LabelNumTransactions"
        Me.LabelNumTransactions.Size = New System.Drawing.Size(204, 18)
        Me.LabelNumTransactions.TabIndex = 17
        Me.LabelNumTransactions.Text = "Number of Transactions:"
        '
        'LabelAvgTransactionAmount
        '
        Me.LabelAvgTransactionAmount.AutoSize = True
        Me.LabelAvgTransactionAmount.BackColor = System.Drawing.Color.Transparent
        Me.LabelAvgTransactionAmount.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelAvgTransactionAmount.Location = New System.Drawing.Point(12, 133)
        Me.LabelAvgTransactionAmount.Name = "LabelAvgTransactionAmount"
        Me.LabelAvgTransactionAmount.Size = New System.Drawing.Size(247, 18)
        Me.LabelAvgTransactionAmount.TabIndex = 18
        Me.LabelAvgTransactionAmount.Text = "Average Transaction Amount:"
        '
        'LabelAvgAmountPaid
        '
        Me.LabelAvgAmountPaid.AutoSize = True
        Me.LabelAvgAmountPaid.BackColor = System.Drawing.Color.Transparent
        Me.LabelAvgAmountPaid.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelAvgAmountPaid.Location = New System.Drawing.Point(12, 177)
        Me.LabelAvgAmountPaid.Name = "LabelAvgAmountPaid"
        Me.LabelAvgAmountPaid.Size = New System.Drawing.Size(186, 18)
        Me.LabelAvgAmountPaid.TabIndex = 19
        Me.LabelAvgAmountPaid.Text = "Average Amount Paid:"
        '
        'LabelAvgChangeGiven
        '
        Me.LabelAvgChangeGiven.AutoSize = True
        Me.LabelAvgChangeGiven.BackColor = System.Drawing.Color.Transparent
        Me.LabelAvgChangeGiven.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelAvgChangeGiven.Location = New System.Drawing.Point(12, 219)
        Me.LabelAvgChangeGiven.Name = "LabelAvgChangeGiven"
        Me.LabelAvgChangeGiven.Size = New System.Drawing.Size(197, 18)
        Me.LabelAvgChangeGiven.TabIndex = 20
        Me.LabelAvgChangeGiven.Text = "Average Change Given:"
        '
        'LabelAvgDateOfTransaction
        '
        Me.LabelAvgDateOfTransaction.AutoSize = True
        Me.LabelAvgDateOfTransaction.BackColor = System.Drawing.Color.Transparent
        Me.LabelAvgDateOfTransaction.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelAvgDateOfTransaction.Location = New System.Drawing.Point(12, 262)
        Me.LabelAvgDateOfTransaction.Name = "LabelAvgDateOfTransaction"
        Me.LabelAvgDateOfTransaction.Size = New System.Drawing.Size(242, 18)
        Me.LabelAvgDateOfTransaction.TabIndex = 21
        Me.LabelAvgDateOfTransaction.Text = "Average Date of Transaction:"
        '
        'ButtonBack
        '
        Me.ButtonBack.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonBack.Location = New System.Drawing.Point(12, 359)
        Me.ButtonBack.Name = "ButtonBack"
        Me.ButtonBack.Size = New System.Drawing.Size(126, 43)
        Me.ButtonBack.TabIndex = 22
        Me.ButtonBack.Text = "Back"
        Me.ButtonBack.UseVisualStyleBackColor = True
        '
        'TextBoxNumTransactions
        '
        Me.TextBoxNumTransactions.Location = New System.Drawing.Point(266, 91)
        Me.TextBoxNumTransactions.Name = "TextBoxNumTransactions"
        Me.TextBoxNumTransactions.Size = New System.Drawing.Size(226, 20)
        Me.TextBoxNumTransactions.TabIndex = 23
        '
        'TextBoxAvgTransactionAmount
        '
        Me.TextBoxAvgTransactionAmount.Location = New System.Drawing.Point(265, 131)
        Me.TextBoxAvgTransactionAmount.Name = "TextBoxAvgTransactionAmount"
        Me.TextBoxAvgTransactionAmount.Size = New System.Drawing.Size(226, 20)
        Me.TextBoxAvgTransactionAmount.TabIndex = 24
        '
        'TextBoxAvgAmountPaid
        '
        Me.TextBoxAvgAmountPaid.Location = New System.Drawing.Point(265, 175)
        Me.TextBoxAvgAmountPaid.Name = "TextBoxAvgAmountPaid"
        Me.TextBoxAvgAmountPaid.Size = New System.Drawing.Size(226, 20)
        Me.TextBoxAvgAmountPaid.TabIndex = 25
        '
        'TextBoxAvgChangeGiven
        '
        Me.TextBoxAvgChangeGiven.Location = New System.Drawing.Point(265, 220)
        Me.TextBoxAvgChangeGiven.Name = "TextBoxAvgChangeGiven"
        Me.TextBoxAvgChangeGiven.Size = New System.Drawing.Size(226, 20)
        Me.TextBoxAvgChangeGiven.TabIndex = 26
        '
        'TextBoxAvgDateOfTransaction
        '
        Me.TextBoxAvgDateOfTransaction.Location = New System.Drawing.Point(266, 263)
        Me.TextBoxAvgDateOfTransaction.Name = "TextBoxAvgDateOfTransaction"
        Me.TextBoxAvgDateOfTransaction.Size = New System.Drawing.Size(226, 20)
        Me.TextBoxAvgDateOfTransaction.TabIndex = 27
        '
        'LabelMostProductiveEmployee
        '
        Me.LabelMostProductiveEmployee.AutoSize = True
        Me.LabelMostProductiveEmployee.BackColor = System.Drawing.Color.Transparent
        Me.LabelMostProductiveEmployee.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMostProductiveEmployee.Location = New System.Drawing.Point(12, 312)
        Me.LabelMostProductiveEmployee.Name = "LabelMostProductiveEmployee"
        Me.LabelMostProductiveEmployee.Size = New System.Drawing.Size(224, 18)
        Me.LabelMostProductiveEmployee.TabIndex = 28
        Me.LabelMostProductiveEmployee.Text = "Most Productive Employee:"
        '
        'TextBoxMostProductiveEmployee
        '
        Me.TextBoxMostProductiveEmployee.Location = New System.Drawing.Point(265, 312)
        Me.TextBoxMostProductiveEmployee.Name = "TextBoxMostProductiveEmployee"
        Me.TextBoxMostProductiveEmployee.Size = New System.Drawing.Size(226, 20)
        Me.TextBoxMostProductiveEmployee.TabIndex = 29
        '
        'Ist2gqDataSet
        '
        Me.Ist2gqDataSet.DataSetName = "ist2gqDataSet"
        Me.Ist2gqDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.tblCustomerTableAdapter = Nothing
        Me.TableAdapterManager.tblInvoiceTableAdapter = Me.TblInvoiceTableAdapter
        Me.TableAdapterManager.tblProductTableAdapter = Nothing
        Me.TableAdapterManager.tblStaffTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Milky_Lane_Point_of_Sales_System.ist2gqDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'TblInvoiceTableAdapter
        '
        Me.TblInvoiceTableAdapter.ClearBeforeFill = True
        '
        'TblStaffTableAdapter
        '
        Me.TblStaffTableAdapter.ClearBeforeFill = True
        '
        'TransactionStatistics
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Milky_Lane_Point_of_Sales_System.My.Resources.Resources.Background
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(535, 414)
        Me.Controls.Add(Me.TextBoxMostProductiveEmployee)
        Me.Controls.Add(Me.LabelMostProductiveEmployee)
        Me.Controls.Add(Me.TextBoxAvgDateOfTransaction)
        Me.Controls.Add(Me.TextBoxAvgChangeGiven)
        Me.Controls.Add(Me.TextBoxAvgAmountPaid)
        Me.Controls.Add(Me.TextBoxAvgTransactionAmount)
        Me.Controls.Add(Me.TextBoxNumTransactions)
        Me.Controls.Add(Me.ButtonBack)
        Me.Controls.Add(Me.LabelAvgDateOfTransaction)
        Me.Controls.Add(Me.LabelAvgChangeGiven)
        Me.Controls.Add(Me.LabelAvgAmountPaid)
        Me.Controls.Add(Me.LabelAvgTransactionAmount)
        Me.Controls.Add(Me.LabelNumTransactions)
        Me.Controls.Add(Me.LabelStatistics)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "TransactionStatistics"
        Me.Text = "Transaction Statistics"
        CType(Me.Ist2gqDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LabelStatistics As Label
    Friend WithEvents LabelNumTransactions As Label
    Friend WithEvents LabelAvgTransactionAmount As Label
    Friend WithEvents LabelAvgAmountPaid As Label
    Friend WithEvents LabelAvgChangeGiven As Label
    Friend WithEvents LabelAvgDateOfTransaction As Label
    Friend WithEvents ButtonBack As Button
    Friend WithEvents TextBoxNumTransactions As TextBox
    Friend WithEvents TextBoxAvgTransactionAmount As TextBox
    Friend WithEvents TextBoxAvgAmountPaid As TextBox
    Friend WithEvents TextBoxAvgChangeGiven As TextBox
    Friend WithEvents TextBoxAvgDateOfTransaction As TextBox
    Friend WithEvents Ist2gqDataSet As ist2gqDataSet
    Friend WithEvents TableAdapterManager As ist2gqDataSetTableAdapters.TableAdapterManager
    Friend WithEvents TblInvoiceTableAdapter As ist2gqDataSetTableAdapters.tblInvoiceTableAdapter
    Friend WithEvents LabelMostProductiveEmployee As Label
    Friend WithEvents TextBoxMostProductiveEmployee As TextBox
    Friend WithEvents TblStaffTableAdapter As ist2gqDataSetTableAdapters.tblStaffTableAdapter
End Class
