﻿Public Class TransactionStatistics
    Private Sub ButtonBack_Click(sender As Object, e As EventArgs) Handles ButtonBack.Click
        Me.Close()

    End Sub

    Private Sub TransactionStatistics_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBoxNumTransactions.Text = TblInvoiceTableAdapter.getNumberOfTransactions()
        TextBoxAvgTransactionAmount.Text = TblInvoiceTableAdapter.getAverageInvoiceAmount()
        TextBoxAvgAmountPaid.Text = TblInvoiceTableAdapter.getAverageAmountPaid()
        TextBoxAvgChangeGiven.Text = TblInvoiceTableAdapter.getAverageAmountPaid() - TblInvoiceTableAdapter.getAverageInvoiceAmount()
        TextBoxAvgDateOfTransaction.Text = TblInvoiceTableAdapter.getAverageDate()

        Dim staffID As Integer = TblStaffTableAdapter.getMostProductiveEmployee()
        TextBoxMostProductiveEmployee.Text = TblStaffTableAdapter.getStaffFirstName(staffID) & " " & TblStaffTableAdapter.getStaffLastName(staffID)

    End Sub
End Class